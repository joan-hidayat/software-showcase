@echo off
echo =========================================================
echo [NEXUS INSTALLER] Memulai instalasi Apotek Smart POS...
echo Menghubungkan ke Central SaaS License Management Dashboard...
echo =========================================================
echo Setup lokal selesai! Silakan buka http://localhost:8080/apotek/ di browser Anda.
pause
