======================================================================
  APOTEK SMART POS & PHARMACY ERP - INSTALLER PACKAGE v2.4.0
======================================================================

Terima kasih telah mengunduh paket resmi Apotek Smart POS & Pharmacy ERP!

PILIHAN 1: INSTALASI DI SERVER LOKAL (XAMPP / LARAGON / ON-PREMISE)
----------------------------------------------------------------------
1. Ekstrak berkas ini ke direktori web server lokal:
   - XAMPP: c:\xampp\htdocs\apotek
   - Laragon: c:\laragon\www\apotek
2. Buka phpMyAdmin (http://localhost/phpmyadmin), buat database 'apotek_db'.
3. Import file database/schema.sql ke dalam database tersebut.
4. Sesuaikan file koneksi database (.env atau config):
   DB_HOST=127.0.0.1
   DB_USER=root
   DB_PASS=
   DB_NAME=apotek_db
5. Buka browser: http://localhost:8080/apotek/
6. Lengkapi form aktivasi lisensi awal yang terhubung ke Central SaaS LMD.

PILIHAN 2: INSTALASI DI SERVER CLOUD / HOSTING PRODUKSI (cPanel / VPS)
----------------------------------------------------------------------
1. Upload & Ekstrak berkas ZIP ke File Manager server Anda:
   - cPanel: public_html/ (atau subfolder/subdomain apotek)
   - VPS Linux (Ubuntu/Debian): /var/www/html/apotek/
2. Buat database baru & user database melalui cPanel Database Wizard 
   atau terminal MySQL, lalu import file database/schema.sql.
3. Atur permission folder storage/cache ke 755 (atau 775).
4. Sesuaikan file .env / config database dengan kredensial server Anda.
5. Atur endpoint lisensi ke Central SaaS LMD Anda:
   LMD_API_URL=https://license.namadomainanda.com/api/licenses/
6. Akses domain Anda di browser: https://apotek.namadomainanda.com/
7. Masukkan kode lisensi resmi untuk mulai beroperasi secara live.

======================================================================
Dukungan & Lisensi:
Didukung penuh oleh Central SaaS License Management Dashboard (LMD).
======================================================================
