// MINI POS EXPRESS - SMART CLIENT APPLICATION
const STORAGE_LICENSE_KEY = 'minipos_license_data';
const STORAGE_CART_KEY = 'minipos_cart';

const PRODUCTS_CATALOG = [
  { id: 1, name: 'Kopi Espresso Blend', category: 'Minuman', price: 18000, emoji: '☕' },
  { id: 2, name: 'Matcha Latte Premium', category: 'Minuman', price: 24000, emoji: '🍵' },
  { id: 3, name: 'Croissant Coklat', category: 'Pastry', price: 22000, emoji: '🥐' },
  { id: 4, name: 'Sandwich Daging Asap', category: 'Makanan', price: 28000, emoji: '🥪' },
  { id: 5, name: 'Air Mineral Prima 600ml', category: 'Minuman', price: 6000, emoji: '💧' },
  { id: 6, name: 'Donat Glaze Vanilla', category: 'Camilan', price: 12000, emoji: '🍩' }
];

const posApp = {
  license: null,
  cart: [],

  init() {
    this.detectLmdHost();
    this.checkLicense();
    this.renderProducts();
    this.bindEvents();
    this.updateCartUI();
  },

  detectLmdHost() {
    // If opened on another device (e.g. 192.168.0.116:8080), use current host as LMD host default
    const currentHost = window.location.hostname || 'localhost';
    const port = window.location.port ? ':' + window.location.port : ':8080';
    const detected = `${window.location.protocol}//${currentHost}${port}`;
    document.getElementById('lmdHost').value = detected;
  },

  checkLicense() {
    const saved = localStorage.getItem(STORAGE_LICENSE_KEY);
    const badge = document.getElementById('licenseBadge');
    const badgeText = document.getElementById('licenseStatusText');
    const modal = document.getElementById('activationModal');

    if (saved) {
      try {
        this.license = JSON.parse(saved);
        badge.className = 'license-badge active';
        badgeText.textContent = `⚡ Aktif (${this.license.license_key ? this.license.license_key.substring(0, 16) : 'LIC'}...)`;
        modal.classList.add('hidden');
      } catch (e) {
        modal.classList.remove('hidden');
      }
    } else {
      badge.className = 'license-badge unverified';
      badgeText.textContent = 'Lisensi Belum Aktif';
      modal.classList.remove('hidden');
    }
  },

  async activateLicense(e) {
    e.preventDefault();
    const btn = document.getElementById('btnActivate');
    const errEl = document.getElementById('activationError');
    errEl.classList.add('hidden');

    const custName = document.getElementById('custName').value.trim();
    const custEmail = document.getElementById('custEmail').value.trim();
    const pkgCode = document.getElementById('packageCode').value;
    const lmdHost = document.getElementById('lmdHost').value.replace(/\/+$/, '');

    btn.disabled = true;
    btn.textContent = 'Menghubungkan ke Central SaaS LMD...';

    const apiUrl = `${lmdHost}/License-Management-Dashboard/api/licenses/register`;

    const payload = {
      app_code: 'APOTEK', // menggunakan app code yang terdaftar di LMD
      package_code: pkgCode,
      customer_name: custName,
      customer_email: custEmail,
      customer_phone: '08123456789',
      instance_key: 'INST-MINIPOS-' + Math.random().toString(36).substring(2, 8).toUpperCase(),
      domain: window.location.hostname || 'localhost'
    };

    try {
      const resp = await fetch(apiUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const json = await resp.json();

      if (json.success && json.data) {
        this.license = json.data;
        this.license.store_name = custName;
        this.license.lmd_host = lmdHost;
        localStorage.setItem(STORAGE_LICENSE_KEY, JSON.stringify(this.license));

        this.checkLicense();
        alert(`Aktivasi Berhasil!\n\nLicense Key: ${json.data.license_key}\nKuota Maksimal: ${json.data.max_users} User`);
      } else {
        throw new Error(json.message || 'Gagal mendaftarkan lisensi');
      }
    } catch (err) {
      errEl.textContent = `Gagal Aktivasi: ${err.message}. Pastikan Central SaaS LMD aktif di ${lmdHost}`;
      errEl.classList.remove('hidden');
    } finally {
      btn.disabled = false;
      btn.textContent = '⚡ Hubungkan & Terbitkan Lisensi Otomatis';
    }
  },

  async sendHeartbeat() {
    if (!this.license || !this.license.license_key) {
      alert('Lisensi belum aktif!');
      return;
    }

    const statusEl = document.getElementById('telemetryStatus');
    statusEl.textContent = 'Mengirim heartbeat telemetri ke LMD...';

    const lmdHost = this.license.lmd_host || (window.location.protocol + '//' + (window.location.hostname || 'localhost') + ':8080');
    const apiUrl = `${lmdHost}/License-Management-Dashboard/api/licenses/validate`;

    try {
      const resp = await fetch(apiUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          license_key: this.license.license_key,
          instance_key: this.license.instance_key || 'INST-DEMO',
          domain: window.location.hostname || 'localhost'
        })
      });

      const res = await resp.json();
      if (res.valid) {
        statusEl.innerHTML = `🟢 Terhubung & Valid! Status: <strong>${res.data.status}</strong> (${res.data.package})`;
      } else {
        statusEl.innerHTML = `🔴 Lisensi tidak valid: ${res.message}`;
      }
    } catch (e) {
      statusEl.textContent = 'Koneksi heartbeat gagal: ' + e.message;
    }
  },

  renderProducts() {
    const grid = document.getElementById('productGrid');
    grid.innerHTML = PRODUCTS_CATALOG.map(p => `
      <div class="product-card" onclick="posApp.addToCart(${p.id})">
        <div>
          <div class="product-emoji">${p.emoji}</div>
          <h3 class="product-title">${p.name}</h3>
          <span class="product-category">${p.category}</span>
        </div>
        <div class="product-price">Rp ${p.price.toLocaleString('id-ID')}</div>
      </div>
    `).join('');
  },

  addToCart(prodId) {
    const item = PRODUCTS_CATALOG.find(p => p.id === prodId);
    if (!item) return;

    const existing = this.cart.find(c => c.id === prodId);
    if (existing) {
      existing.qty++;
    } else {
      this.cart.push({ ...item, qty: 1 });
    }
    this.updateCartUI();
  },

  changeQty(prodId, delta) {
    const idx = this.cart.findIndex(c => c.id === prodId);
    if (idx === -1) return;

    this.cart[idx].qty += delta;
    if (this.cart[idx].qty <= 0) {
      this.cart.splice(idx, 1);
    }
    this.updateCartUI();
  },

  clearCart() {
    this.cart = [];
    this.updateCartUI();
  },

  updateCartUI() {
    const list = document.getElementById('cartItemsList');
    const btnCheckout = document.getElementById('btnCheckout');
    const subtotalEl = document.getElementById('subtotalVal');
    const taxEl = document.getElementById('taxVal');
    const totalEl = document.getElementById('totalVal');

    if (this.cart.length === 0) {
      list.innerHTML = `
        <div class="cart-empty">
          <div style="font-size: 32px; margin-bottom: 8px;">🛒</div>
          <p>Belum ada produk dipilih</p>
          <small>Klik menu di sebelah kiri untuk menambah transaksi</small>
        </div>
      `;
      btnCheckout.disabled = true;
      subtotalEl.textContent = 'Rp 0';
      taxEl.textContent = 'Rp 0';
      totalEl.textContent = 'Rp 0';
      return;
    }

    btnCheckout.disabled = false;
    let subtotal = 0;

    list.innerHTML = this.cart.map(c => {
      const itemTotal = c.price * c.qty;
      subtotal += itemTotal;
      return `
        <div class="cart-item">
          <div class="item-info">
            <strong>${c.emoji} ${c.name}</strong>
            <span>Rp ${c.price.toLocaleString('id-ID')} x ${c.qty}</span>
          </div>
          <div class="item-controls">
            <button class="qty-btn" onclick="posApp.changeQty(${c.id}, -1)">-</button>
            <span style="font-size:13px; font-weight:700;">${c.qty}</span>
            <button class="qty-btn" onclick="posApp.changeQty(${c.id}, 1)">+</button>
          </div>
        </div>
      `;
    }).join('');

    const tax = Math.round(subtotal * 0.11);
    const total = subtotal + tax;

    subtotalEl.textContent = `Rp ${subtotal.toLocaleString('id-ID')}`;
    taxEl.textContent = `Rp ${tax.toLocaleString('id-ID')}`;
    totalEl.textContent = `Rp ${total.toLocaleString('id-ID')}`;
  },

  checkout() {
    if (this.cart.length === 0) return;

    const receiptModal = document.getElementById('receiptModal');
    const receiptItems = document.getElementById('receiptItems');
    const receiptTotal = document.getElementById('receiptTotal');
    const receiptStoreName = document.getElementById('receiptStoreName');
    const receiptLicense = document.getElementById('receiptLicenseCode');
    const receiptDate = document.getElementById('receiptDate');

    receiptStoreName.textContent = (this.license && this.license.store_name) ? this.license.store_name : 'Mini POS Express';
    receiptDate.textContent = new Date().toLocaleString('id-ID');
    receiptLicense.textContent = 'Lisensi: ' + (this.license ? this.license.license_key : 'UNLICENSED');

    let subtotal = 0;
    receiptItems.innerHTML = this.cart.map(c => {
      const lineTotal = c.price * c.qty;
      subtotal += lineTotal;
      return `
        <div class="receipt-item-row">
          <span>${c.name} x${c.qty}</span>
          <span>${lineTotal.toLocaleString('id-ID')}</span>
        </div>
      `;
    }).join('');

    const tax = Math.round(subtotal * 0.11);
    const grandTotal = subtotal + tax;

    receiptItems.innerHTML += `
      <div class="receipt-item-row" style="color:#6b7280; font-size:11px; margin-top:4px;">
        <span>PPN (11%)</span>
        <span>${tax.toLocaleString('id-ID')}</span>
      </div>
    `;

    receiptTotal.textContent = `Rp ${grandTotal.toLocaleString('id-ID')}`;
    receiptModal.classList.remove('hidden');

    // Automatically send heartbeat telemetri
    this.sendHeartbeat();
  },

  bindEvents() {
    document.getElementById('activationForm').addEventListener('submit', (e) => this.activateLicense(e));
    document.getElementById('btnClearCart').addEventListener('click', () => this.clearCart());
    document.getElementById('btnCheckout').addEventListener('click', () => this.checkout());
    document.getElementById('btnCloseReceipt').addEventListener('click', () => {
      document.getElementById('receiptModal').classList.add('hidden');
      this.clearCart();
    });
    document.getElementById('btnTestValidate').addEventListener('click', () => this.sendHeartbeat());
  }
};

document.addEventListener('DOMContentLoaded', () => posApp.init());
